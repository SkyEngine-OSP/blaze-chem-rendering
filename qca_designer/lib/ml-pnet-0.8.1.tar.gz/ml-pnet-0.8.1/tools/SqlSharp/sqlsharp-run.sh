#!/usr/bin/env clrwrap
sqlsharp-pnet.exe
