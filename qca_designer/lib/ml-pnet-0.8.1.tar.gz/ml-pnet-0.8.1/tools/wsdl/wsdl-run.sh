#!/usr/bin/env clrwrap
wsdl-pnet.exe
